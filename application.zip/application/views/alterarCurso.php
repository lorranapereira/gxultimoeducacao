<?php
require_once("layout/navbar.php");

?>
  
<!-- Side Widget -->
<div class="container">
<br/>
<br/>
<br/>
<br/>
<div class="row">
<div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
  <div class="card card-signin my-5">
    <div class="card-body">
          <h4 style="font-size:22px;font-family:'Source Sans Pro', sans-serif;" class="card-title text-center">Alterar Curso</h4>
            <?php
                if ($this->session->flashdata('error')) {
                ?>
                    <div class="alert alert-danger text-center" style="margin-top:20px;">
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                    <?php
                }
            ?> 
          <form class="form-signin" action="/index.php/Control/alterarCurso" method="POST">
          <?php foreach ($curso as $linha): ?> 
              <div class="form-label-group">
                <label for="inputEmail">Nome do Curso</label>                        
                <input type="text" name="titulo" class="form-control" value="<? echo $linha->titulo ?>" placeholder="Nome do Curso" required autofocus>
              </div>
              <br/>
              <input type="text" name="id_curso" value="<? echo  $linha->id ?>" style="display:none" >
              <label for="">Adicionar Clientes</label>
              <div class="form-check" style="display:float;">
                <?php foreach ($users as $row): ?>
                    <input class="form-check-input"  name="clientes[]" style="position:relative;" value="<? echo $row->id; ?>" type="checkbox" id="defaultCheck1" 
                     <?php foreach ($userAntigo as $user):                                   
                       if($user->id == $row->id){
                         echo "checked";
                       }
                    
                       endforeach 
                    ?> >

                   <label style="font-weight: normal;" class="form-check-label" for="defaultCheck1">
                   <? echo $row->nome; ?> </label>

                  </li>
                  <br/>

                <?php endforeach ?>
              </div>
              <br/>
              <div class="form-label-group">
                <label for="inputPassword">Preço</label>                        
                <input type="number" id="inputPassword" value="<? echo $linha->preco ?>" name="preco" class="form-control" step="0.01" placeholder="Preço" required>
              </div>
              <br/>
              <div class="form-label-group">
                <label for="inputPassword">Informação</label><br/>                      
                <textarea name="info" id="" style="position:relative;width:100%" cols="30" rows="5" required> <? echo $linha->info ?></textarea> 
              </div>
              <br/>
              <?php endforeach ?>

              <button type="submit" class="btn btn-primary">Enviar</button>
              <hr class="my-4">
          </form>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>
  </div>


    <!-- /.row -->

  <!-- /.container -->
<?php
  require_once("layout/footer.php");  
?>