<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light fixed-top"  style="background-color:white!important;">
    <div class="container">
    <img class="logo" width="20%;" src="/css/gxeduca.png" alt="">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="ollapse navbar-collapse justify-content-end" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item <? if($_SERVER['REQUEST_URI'] != '/index.php/Control/cursos') { echo 'active'; } ?>">
                <a class="nav-link" href="/index.php/Control">Página inicial</a>
            </li>
            <li class="nav-item <? if($_SERVER['REQUEST_URI'] == '/index.php/Control/cursos') { echo 'active'; } ?>">
                <a class="nav-link" style="text-decoration:none" href="/index.php/Control/cursos">Cursos</a>
            </li>
            <li class="nav-item">
                <button style="position:relative;top:1em;font-size:1.8rem;" class="btn btn-primary" data-toggle="modal" data-target="#ExemploModalCentralizado">
                Área do aluno
                </button>

            </li>
        </ul>
        </div>
    </div>
    </nav>


<div class="modal fade" id="ExemploModalCentralizado" tabindex="-1" role="dialog" aria-labelledby="TituloModalCentralizado" aria-hidden="true">
    <div  class="modal-dialog modal-dialog-centered" role="document">
        <div style="background-color:#212529;color:white;" class="modal-content">
            <div class="modal-header">
            <h1 style="position:relative;left:25%;font-size:2.5rem;" class="modal-title" id="TituloModalCentralizado">Acesse sua conta!</h1>
            <button  style="border-radius:10%;top:0.2em;height:6%;background-color:white;" type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
            <?php
            if ($this->session->flashdata('error')) {
            ?>
                <div class="alert alert-danger text-center" style="margin-top:20px;font-size:2rem">
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
                <?php
            }
        ?> 
            <form class="form-signin" style="position:relative;font-size:1.8rem;" action="/index.php/Control/logar" method="POST">
                <div class="form-label-group">
                <label for="inputEmail">Email</label>                        
                <input type="email"  id="email2" name="email" class="form-control" placeholder="Email" required>
                </div>
                <br/>
                <div class="form-label-group">
                <label for="inputPassword">Senha</label> 
                <input type="password" id="senha2"  name="senha" class="form-control" placeholder="Senha" required >
                </div>
                <br/>
                <button  class="btn btn-ms btn-primary btn-block text-uppercase" style="position:relative;left:25%;
                border-radius: 15px;width:50%;font-size:1.8rem;" 
                type="submit">Logar</button>  
                <br/>
                <hr style="background-color:blue;" class="my-4">
                <a id="cad3" href="/index.php/Control/formcad" >Não possui conta? Cadastre-se</a>        
                </div>
 
            </form>
            </div>
        </div>
    </div>
</div>