
	<div style="position:relative;height:10%;" class="row">
	<img   style="position:relative;width:100%;height:250px;"  src="/css/fundo.jpg" alt="">
	</div>
	<div class="container">
	<br/>

	<div style="position:relative;top:10em;" class="row">
		<!-- Sidebar Widgets Column -->
		<div class="col-md-4">
		<div class="card my-4" style="position:relative;left:-22%;background-color:rgba(82, 54, 54, 0);top:-13.2em;width:100%;height:85%;border:1px solid rgba(82, 54, 54, 0); margin: 0 0 0 0;">
		<br/>
		<div class="container2">
		<?php foreach ($perfil as $foto): ?>      
			<img src="/perfil/<? echo $foto->foto ?>" id="img" class="rounded-circle" alt="Avatar" style="width:67%;left:-2%;height:15em;">
		<?php endforeach ?>
		<div class="alert alert-danger" id="danger" style="display:none;left:-10%;" role="alert">
			Nenhuma imagem foi selecionada!
		</div>
		<div class="middle">
		<form id="form" name="form" enctype="multipart/form-data" method="POST">

		<div class="form-group" style="display:flex;width:100%;height:2.5em;">
		<label style="cursor:pointer;color:blue;" for="exampleFormControlFile1"> Alterar foto do perfil</label>&nbsp
			<input style="position:relative;left:15%;color:white;" name="foto" type="file" class="form-control-file" id="exampleFormControlFile1">   <br/>      
			<button type="button" id="buttonfoto" style="display:none;" class="btn btn-primary">Salvar</button>
			</div>
		</form>
		</div>
	</div>
	<br/>

		<p   class="text-center" style="font-size:22px;color:black;"><? echo $_SESSION['nome']." ".$_SESSION['sobrenome']; ?></p>

			<h5 id="titulo1" class="card-header"> <strong style="font-size:22px; color:#244c74;">Meus Cursos</strong> </h5>
			<div id="card1" class="card-body">
			<div class="row">
				<div class="col-lg-12" >
				<ul class="list-unstyled mb-0">
				<?php foreach ($meuscursos as $row): ?>      
				
					<li>
				<!--   <li>  <a href="meucurso?id_curso=echo $row->id."&ep_video=1"; "  style="font-size:18px; color:#0053ff;" ><strong> echo $row->titulo; </strong></a>
					</li> !-->
					</li>
					<a href="videoaulas"  style="font-size:18px; color:#0053ff;" ><strong><?echo $row->titulo; ?></strong></a>
				<?php endforeach ?>
				</ul>

				</div>
			</div>
			</div>
			<br/>
			<h5 class="card-header" id="titulo2" > <strong style="font-size:22px; color:#244c74;">Cursos Gx Investimento</strong></h5>
			<br/>
			<div id="card2" class="col-lg-12" >
			<ul class="list-unstyled mb-0">
			<?php foreach ($gxcursos as $row): ?> 
				<li>
					<a href="cursosgx" ><strong style="font-size:18px!important;" ><? echo $row->titulo; ?></strong>
					<i class="fa fa-shopping-cart"  style="font-size:18px;color:#0053ff;"></i></a>
				</li>

				<?php endforeach ?>
				</ul>    
			</div>
			<br/>

			</div>
		</div>
	<script>
	document.getElementById('exampleFormControlFile1').addEventListener('click',function() {
		document.getElementById("buttonfoto").style.display = "block";
	});
	</script>
	<script src="/js/alterarfotocurso.js"></script>
	<script>

	document.getElementById('buttonfoto').addEventListener('click',function() {
		var extension = new Array("jpg","jpeg","png","ico","gif");
		file = document.getElementById("exampleFormControlFile1").value;
		if(file==""){
			document.getElementById("danger").style.display = "block";
			document.getElementById("buttonfoto").style.display = "none";


		}
		else {
			document.getElementById("buttonfoto").style.display = "none";
			document.getElementById("danger").style.display = "none";
			file = document.getElementById("exampleFormControlFile1").value;
			extaux = file.split('.').pop();;
			var ext = extaux.toLowerCase();
			if(extension.indexOf(ext) !=-1){
				var formData = new FormData(document.getElementById("form"));
				alterarFoto(formData);
			}
			else {
				alert("Formato incorreto da imagem\n Extenções aceitas:jpg,jpeg,png,ico,gif");
			}
		}
	});
      
</script>
<script src="jquery-3.4.1.min.js"></script>

<script>
	/* SCRIPT JQUERY PARA TROCAR DE COR NAVBAR */
	$(window).scroll(function () {
		if ($(this).scrollTop() > 50) {
			$('.navbar').css("background-color", "rgba(35, 66, 106, 0.78)")
		} else {
			$('.navbar').css("background-color", "transparent")
		}
	});
</script>