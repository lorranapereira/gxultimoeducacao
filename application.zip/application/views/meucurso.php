<?php
require_once("layout/navbar.php");

?>
  <!-- Page Content -->
  <div  class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3">
      <small style="color:#244c74"><?php foreach($curso as $atual):
             echo $atual->titulo;
             endforeach
        ?></small>
    </h1>


    <!-- Portfolio Item Row -->
    <div class="row" style="position:relative;box-shadow: 0 0 0.5em gray;">

      <div class="col-md-7" style="position:relative;box-shadow: 0 0 0.5em #244c74;">
      <?php foreach($videos as $atual): ?>
            <video width="100%" height="100%" controls="controls">
            <source src="<? echo "/videos/".$atual->nome ?>">
            <object data="" width="320" height="240">
            <embed width="320" height="240" src="<? echo "/videos/".$atual->nome ?>">
            </object>
      </div>

      <div class="col-md-4">
        <h3 class="my-3"><? echo $atual->titulo ?></h3>
        <p><? echo $atual->descricao ?></p>

      </div>
      <?  endforeach  ?>

    </div>
    <!-- /.row -->
    <br/>
    <h3 class="my-4" style="border-bottom: 1px solid #244c74; padding:20px;">Próximas aulas</h3>
    <div class="row">
        <?php foreach($videomenos1 as $atual): ?>
          <div style="position:relative;box-shadow: 0 0 0.5em gray;"class="col-md-3 col-sm-6 mb-4">
              <h4 style="position:relative;color:#244c74;top:1em;"><? echo $atual->titulo ?></h4>
              <br/>
              <a href="assistirNovoEp?id_video=<? echo $atual->id  ?>&ep=<?  echo $atual->ep?>&cod_curso=<?  echo $atual->cursoid?>">              

              <video width="100%" height="240" style="position:relative;top:-2em;" controls="controls">
              <source src="<? echo "/videos/".$atual->nome ?>">
              <object data="" width="320" height="240">
              <embed width="320" height="240" src="<? echo "/videos/".$atual->nome ?>">
              </object>
              </a>
          </div>
        <?  endforeach  ?>

    </div>
    <!-- /.row -->

  </div>
  </div>

  <!-- /.container -->

<?php
require_once("layout/footer.php");

?>