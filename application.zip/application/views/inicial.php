<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html lang="en">

<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Gx educação</title>
  <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Rubik:500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="/css/favicon.ico" type="image/x-icon">
  <link href="https://fonts.googleapis.com/css?family=Heebo&display=swap" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari|Playfair+Display&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">

  <link rel="stylesheet" href="/css/style.css" >
  <link href="/css2/style.css" rel="stylesheet">



  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<?php
require_once("layout/navbar.php");  
require_once("layout/menu.php");

?>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar publicação</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="alterarPublicacao">
          <div class="form-group">
            <label for="message-text" class="col-form-label">Mensagem:</label>
            <textarea class="form-control" name="msg"    id="message-text"></textarea>
          </div>
          <div class="form-group">
            <input class="form-control" id="id" name="id" style="position:relative;display:none;" type="text">
          </div>
          <button type="submit" class="btn btn-success" >Salvar</button>
        </form>
      </div>
      <div class="modal-footer">
        <a class="btn btn-dark" href="#" role="button" data-dismiss="modal">Fechar</a>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Comentário</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="alterarComentario">
          <div class="form-group">
            <label for="message-text" class="col-form-label">Mensagem:</label>
            <textarea class="form-control" name="comentario"    id="message-text"></textarea>
          </div>
          <div class="form-group">
            <input class="form-control" style="display:none;" id="message-text" name="id_comentario" type="text">
          </div>
          <button type="submit" class="btn btn-success" >Salvar</button>
        </form>
      </div>
      <div class="modal-footer">
        <a class="btn btn-dark" href="#" role="button" data-dismiss="modal">Fechar</a>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<!-- Side Widget -->
<div id="corpo" class="col-md-8" style="background-color: white;top:2em;">
    <div class="form-group shadow-textarea">
      <form action="publicar" method="post">
        <button type="submit" id="publicar" class="btn btn-primary">Publicar</button>
        <input name="id_user" style="display:none;"  value="<? echo $_SESSION['id']?>">
        <input name="data" style="display:none;"  value="<?
                date_default_timezone_set('America/Sao_Paulo');
                // CRIA UMA VARIAVEL E ARMAZENA A HORA ATUAL DO FUSO-HORÀRIO DEFINIDO (BRASÍLIA)
                $hoje = date('d-m-Y', time());
                $semana = date('N', time());
                if($semana == "1") {
                  $semana = "Seg"; 
                }
                if($semana == "2") {
                  $semana = "Ter";
                }
                if($semana == "3") {
                  $semana = "Qua";
                  
                }
                if($semana == "4") {
                  $semana == "Qui";
                }
                if($semana == "5") {
                  $semana = "Sex";
                }
                if($semana == "6") {
                  $semana = "Sab";
                }
                if($semana == "7") {
                  $semana = "Dom";
                }
                $databanco = date('Y-m-d H:i:s', time());                
                echo $databanco;

                  ?>">
        <textarea  name="publicacao"  id="postar" class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="Compartilhe informações, dúvidas ..." autofocus></textarea>
      </form>
    </div>
    <div style="position:relative;top:-1.3em;">
      <?php foreach($listpublic as $public): ?>
      <div  class="card mb-4">
        <div  style="position:relative;height:4em;" class="card-header">
        <img src="/perfil/<? echo $public->foto ?>" id="imgpublic" class="rounded-circle" alt="Avatar" style="position:relative;left:3%;width:8%;height:2.8em;">
        <p class="card-title" id="publicnomet" style="position:relative;top:-3em;color:#244c74;width:50%;left:15%;"><? echo $public->nome." ".$public->sobrenome; ?></p>
        <p id="publicp" style="position:relative;font-size:12px;top:-5em;left:18%;color:gray;"> <?                
         // $data = $semana." às ".date("y-m-d h:i", $public->data);
         $date = (new DateTime($public->data));         
         $data = $date->format("d-m-Y") ;
         $ontem = date('d-m-Y',strtotime("-1 days"));
         if($hoje == $data){
          $date = (new DateTime($public->data));
            echo "hoje às ".$date->format("H:i");          
         }
         if($data ==  $ontem){
          echo "Ontem às ".$date->format("H:i");          
         }
         if($data !=  $ontem && $data !=  $hoje ) {
          
          echo $data;
        }
        
         
    //      echo $data;
         //  echo date($public->data); ?> </p>
        </div>
            <div class="card-body">
                <input style="display:none" data-id = "<?  echo  $public->id;?>" >
                <? echo  $public->mensagem;  ?>
            </div>
            <div  style="position:relative;height:2.2em;" class="card-header">
              <a style="position:relative;top:-0.8em;color:#385898;text-decoration:none;font-size:13px;" href="#" > Comentários </a>
              <? if($_SESSION['id'] == $public->id_user): ?>
                <a href="deletarPublic?id=<? echo $public->id;  ?>" id="deletarPublic"  style="position:relative;top:-0.8em;padding-left:60%;color:#385898;text-decoration:none;font-size:12px;"><i class="fa fa-remove" style="position:relative;color:#385898;font-size:15px;" id="deletarPublicicon" aria-hidden="true"></i> &nbsp Deletar</a>  &nbsp  &nbsp
                <a  href="#"  data-toggle="modal" id="editPublic" data-target="#exampleModal" data-whatever="<? echo  $public->mensagem."-".$public->id; ?>" style="position:relative;top:-0.8em;text-decoration:none;color:#385898;font-size:12px;"><i class="fa fa-edit" style="color:#385898;font-size:15px;" aria-hidden="true"></i> &nbsp Editar</a>
                <? endif ?>
            </div>
            <?php foreach($listcomentarios as $coment):
              if($coment->id_publicacao == $public->id ): ?>
            <div style="position:relative;margin:0;border:none;overflow:auto;"class="card mb-4">
              <div  style="position:relative;border-bottom:1px solid rgba(0,0,0,.125);background-color:white; " >
                  <div  style="position:relative;height:100%;border:none" >
                   <img src="/perfil/<? echo $coment->foto ?>" id="fotocoment" class="rounded-circle" alt="Avatar" style="position:relative;left:3%;top:1.5em;width:4.5%;height:2.5em;">
                   <p id="nomep" style="position:relative;top:-1em;left:10%;font-size:12px;color:#043c75;width:60%;"><? echo $coment->nome." ".$coment->sobrenome; ?> </p>
                   <p  id="comentp" style="position:relative;top:-1.9em;left:10%;font-size:15px;color:black;width:90%;"> <? echo $coment->comentario;?><br/>
                   <? if ($_SESSION['id'] == $coment->id_user): ?>
                     <a href="deletarComentario?id=<? echo $coment->id_comentario ?>"   style="color:#385898;text-decoration:none;font-size:10px;"><i class="fa fa-remove" style="color:#385898;font-size:10px;" aria-hidden="true"></i> &nbsp Deletar</a>  &nbsp  &nbsp
                     <a  data-toggle="modal" data-target="#exampleModal2" data-whatever="<? echo  $coment->comentario."-".$coment->id_comentario; ?>"  href="#" style="color:#385898;text-decoration:none;font-size:10px;"><i class="fa fa-edit" style="color:#385898;font-size:10px;" aria-hidden="true"></i> &nbsp Editar</a>
                   <? endif ?> </p>

                  <input style="display:none" data-id = "<?  echo  $public->id;?>" >

                </div>
                </div>
            </div>
            <? endif ?>
            <? endforeach ?>
            <div class="row">

            <form action="comentarVideo" style="position:relative;width:100%;" method="post">
            <div class="form-group form-check">
            <i id="iconc" style="position:relative;font-size:25px;left:4%;top:0.8em;color:#043c75;width:1%;" class="fa fa-user-circle-o"> </i> 
              <input style="display:none;" id="inputcoment" type="text" class="form-control" name="id_comentario" placeholder="Comentar" value="<? echo $coment->id_comentario; ?>" aria-describedby="basic-addon1">
              <input style="display:none;" id="inputcoment" type="text" class="form-control" name="id_publicacao" placeholder="Comentar" value="<? echo $public->id; ?>" aria-describedby="basic-addon1">
              <input style="position:relative;left:9%;top:-0.8em;color:#043c75;width:80%;" id="inputcoment" type="text" class="form-control" name="comentario" placeholder="Comentar" aria-describedby="basic-addon1">
            </div>

              <button class="btn btn-light" id="buttonc" type="submit"  style="position:relative;left:90%;top:-4em;border:0.5px solid  gray!important;border-radius:50%;background-color:white;color:#043c75;width:5%;"><i style="position:relative;left:-0.5em;width:10%;color:blue;" class="fa fa-paper-plane" aria-hidden="true"></i></button>          
            </form>
          </div>


          </div>

      <? endforeach ?>
      </div>
      </div>


      <!-- Pagination -->
  
    </div>
    </div>
    </div>  
    <br/>
    <br/>
    <br/>
    <br/>

<script>
$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Botão que acionou o modal
  var recipient = button.data('whatever') // Extrai informação dos atributos data-*
  resultado = recipient.split("-");
  var msg = resultado[0];
  var id = resultado[1]; // Extrai informação dos atributos data-*
  // Se necessário, você pode iniciar uma requisição AJAX aqui e, então, fazer a atualização em um callback.
  // Atualiza o conteúdo do modal. Nós vamos usar jQuery, aqui. No entanto, você poderia usar uma biblioteca de data binding ou outros métodos.
  var modal = $(this)
  modal.find('.modal-body input').val(id)
  modal.find('.modal-body textarea').val(msg)
 console.log(resultado);
})

$('#exampleModal2').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Botão que acionou o modal
  var recipient = button.data('whatever') // Extrai informação dos atributos data-*
  resultado = recipient.split("-");
  var msg = resultado[0];
  var id = resultado[1]; // Extrai informação dos atributos data-*
  // Se necessário, você pode iniciar uma requisição AJAX aqui e, então, fazer a atualização em um callback.
  // Atualiza o conteúdo do modal. Nós vamos usar jQuery, aqui. No entanto, você poderia usar uma biblioteca de data binding ou outros métodos.
  var modal = $(this)
  modal.find('.modal-body input').val(id)
  modal.find('.modal-body textarea').val(msg)
})
</script>

    <!-- /.row -->

  <!-- /.container -->
<?php
  require_once("layout/footer.php");  
?>