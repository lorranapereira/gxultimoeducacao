<?php
require_once("layout/navbar.php");

?>
	<div class="container">
	<br/> 
	<br/>
	<div class="row">
	<div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
		<div class="card card-signin my-5">
		<div class="card-body">
			<h5 class="card-title text-center">Alterar Conta</h5>
			<br/>
			<div id="alertsucesso" style="display:none;" class="alert alert-success" role="alert">
				 Senha alterada com sucesso!
			</div>
			<button type="submit" id="alterar" class="btn btn-warning" data-toggle="modal" data-target="#ExemploModalCentralizado">
                Alterar senha
            </button>

			<form class="form-signin" action="/index.php/Control/minhaconta" method="POST">
			<div class="form-label-group">
			<br/>
			<?php foreach($user as $u): ?>
					<label for="inputPassword">Nome</label>                        
					<input type="text" id="name" value="<? echo $u->nome ?>" name="nome" class="form-control" placeholder="Nome" required autofocus>
				</div>
				<br/>
				<div class="form-label-group">
					<label for="inputPassword">Sobrenome</label>                        
					<input type="text" id="name" name="sobrenome"  value="<? echo $u->sobrenome ?>" class="form-control" placeholder="Sobrenome" required>
				</div>
				<br/>
				<div class="form-label-group">
				<label for="inputEmail">Email</label>                        
				<input type="email" id="inputEmail" name="email" value="<? echo $u->email ?>" class="form-control" placeholder="Email" required >
				</div>
				<br/>                     
				<p style="display:none;" type="password" id="senhabanco" >
				<?= $u->senha; ?>
				</p>
				<div class="form-label-group">
				<br/>
				<label for="inputPassword">Telefone</label>                        
				<input type="tel" id="inputPassword" name="tel" value="<? echo $u->numero ?>"  class="form-control" placeholder="Whatsapp" required>
				</div>
				<br/>
				<button class="btn btn-ms btn-primary btn-block text-uppercase" type="submit">Salvar</button>
				<hr class="my-4">
				<?  endforeach  ?>

			</form>
		</div>
		</div>
	</div>
	</div>
	</div>
	</div>
	</div>

	<br/>
	<br/>
	<div class="modal fade" id="ExemploModalCentralizado" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Alteração senha</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
			<form class="needs-validation" >
				<div id="alertsenha" style="display:none;" class="alert alert-danger" role="alert">
				 Senha não confere com atual
				</div>
				<div class="form-row">
					<div class="col-md-4 mb-3">
						<label for="validationCustom01">Senha Atual</label>
						<input type="password" id="senhaantiga" minlength="99999" class="form-control" id="senhaantiga" placeholder="Senha atual"  required>
					</div>
					<div class="col-md-4 mb-3">
						<label for="validationCustom02">Nova Senha </label>
						<input type="password" minlength="99999" class="form-control" id="senhanova" placeholder="Nova senha"  required>
					</div>
				</div>
				<button class="btn btn-primary" id="buttonsenha" type="button">Confirmar</button>
			</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
			</div>
			</div>
		</div>
		</div>
	</div>
	<br/>
	<br/>
	<br/> 

  <?php
  require_once("layout/footer.php");
  
  ?>


<script src="/js/confirmarsenha.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.0.0/core.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/md5.js"></script>
<script src="jquery-3.4.1.min.js"></script>

<script>
document.getElementById("alertsenha").style.display = "none";
document.getElementById('buttonsenha').addEventListener('click',function() {
	var senhabanco = document.getElementById("senhabanco").textContent;
	var senhaantiga= document.getElementById("senhaantiga").value;
	var senhanova = document.getElementById("senhanova").value;
	var senha = CryptoJS.MD5(senhaantiga);
	var senhac = senha.toString();
	senhadobanco = senhabanco.trim();
	if (senhadobanco == senhac){
		document.getElementById("alertsucesso").style.display = "block";
		$('#ExemploModalCentralizado').modal('hide');
		document.getElementById("alertsenha").style.display = "none";
		document.getElementById("alterar").disabled = true;
		console.log(senhadobanco+"---"+senhac);
		mudarsenha(senhanova);

	}else{
		document.getElementById("alertsenha").style.display = "block";
	}
});
</script>
