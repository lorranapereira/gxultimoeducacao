<?php
require_once("layout/navbar.php");

?>
<div id="body" style = "position:relative;background-attachment: fixed!important;
            background-position: center!important; background-image:url(/css/curso3.jpg); background-size:cover;">
    <!-- Page Content -->
  <div class="container"  >

    <!-- Page Heading/Breadcrumbs -->
    <br/>
    <br/>
    <br/>



    <!-- Blog Post -->
    <div class="row" >
    <?php foreach ($gxcursos as $row): ?> 
      <br/>
      <div class="row" style="position:relative;margin:10px;font-family: 'Playfair Display', serif;color:white;">
    <br/>
        <h1>
          <strong style="font-size:50px;color:white;font-family: 'Playfair Display', serif;text-shadow: -1px 3px 0px black;"><? echo $row->titulo; ?></strong>
        </h1>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <h4 class="card-text" style="color:white;font-size:30px;"><?echo $row->info; ?></h4>
        <div class="row">
        <div class="col-md-6">
        </div>
        <br/>
        <br/>
        <form action="curso" method="post">
          <input style="display:none;" name="cursoid" value="<? echo $row->id ?>" style="position:relative;" >
          <p style="font-size:22px;color:red">Vagas esgotadas!</p>
          <p style="font-size:22px;" >Em breve abriremos novas turmas</p>
        <!--  <a style="font-size:25px;left:10%;margin:10px;background-color:black;color:white;" href="https://materiais.gxinveste.com.br/jornada-do-investidor" class="btn btn-primary btn-lg">Saiba mais &nbsp<i class="fa fa-plus" style="font-size:30px;color:white"></i></a>
        !-->
      <!-- <button type="submit"  style="font-size:25px;left:10%;margin:10px;background-color:black;color:white;" class="btn btn-primary btn-lg">Saiba mais &nbsp<i class="fa fa-plus" style="font-size:30px;color:white"></i></button>
       !-->
        </form>
        </div>
      </div>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
    <?php endforeach ?>


  </div>
  </div>
  </div>

  <!-- /.container -->
  <?php
  require_once("layout/footer.php");
  
  ?>
