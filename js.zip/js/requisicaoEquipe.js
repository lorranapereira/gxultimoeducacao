
function captacaoTotal(cidade) {
    $.ajax ({
        url: '/index.php/Total/captacaoTotal',
        type: 'POST',
        async: true,
        dataType: 'json',
        data:{'cidade': cidade},
        
        success: function (result)
        { 
            document.getElementById('loading1').style.display = 'none';            
            mensalChart.data.datasets.push({
                label: 'Aplicado',
                fill: false,
                borderColor:'rgba(48, 165, 29, 0.57)',
                backgroundColor: 'rgba(48, 165, 29, 0.57)',
                data: [ 
                    (result.mensal[0][0].realizado), (result.mensal[1][0].realizado), (result.mensal[2][0].realizado), (result.mensal[3][0].realizado), (result.mensal[4][0].realizado), (result.mensal[5][0].realizado), (result.mensal[6][0].realizado), (result.mensal[7][0].realizado), (result.mensal[8][0].realizado), (result.mensal[9][0].realizado), (result.mensal[10][0].realizado), (result.mensal[11][0].realizado), (result.mensal[12][0].realizado), (result.mensal[13][0].realizado), (result.mensal[14][0].realizado), (result.mensal[15][0].realizado), (result.mensal[16][0].realizado), (result.mensal[17][0].realizado), (result.mensal[18][0].realizado), (result.mensal[19][0].realizado), (result.mensal[20][0].realizado), (result.mensal[21][0].realizado), (result.mensal[22][0].realizado), (result.mensal[23][0].realizado), (result.mensal[24][0].realizado), (result.mensal[25][0].realizado), (result.mensal[26][0].realizado), (result.mensal[27][0].realizado), (result.mensal[28][0].realizado), (result.mensal[29][0].realizado), (result.mensal[30][0].realizado)]
              });
            mensalChart.update();
            mensalChart.data.datasets.push({
                label: 'Declarado',
                fill: false,
                backgroundColor: 'rgba(222, 139, 63, 0.70)',
                borderColor: 'rgba(222, 139, 63, 0.70)',
                data: [ 
                    (result.mensal[0][0].soma), (result.mensal[1][0].soma), (result.mensal[2][0].soma), (result.mensal[3][0].soma), (result.mensal[4][0].soma), (result.mensal[5][0].soma), (result.mensal[6][0].soma), (result.mensal[7][0].soma), (result.mensal[8][0].soma), (result.mensal[9][0].soma), (result.mensal[10][0].soma), (result.mensal[11][0].soma), (result.mensal[12][0].soma), (result.mensal[13][0].soma), (result.mensal[14][0].soma), (result.mensal[15][0].soma), (result.mensal[16][0].soma), (result.mensal[17][0].soma), (result.mensal[18][0].soma), (result.mensal[19][0].soma), (result.mensal[20][0].soma), (result.mensal[21][0].soma), (result.mensal[22][0].soma), (result.mensal[23][0].soma), (result.mensal[24][0].soma), (result.mensal[25][0].soma), (result.mensal[26][0].soma), (result.mensal[27][0].soma), (result.mensal[28][0].soma), (result.mensal[29][0].soma), (result.mensal[30][0].soma)]
              });
          mensalChart.update();

        }
    })
}

function receitaTotal(cidade) {
    $.ajax ({
        url: '/index.php/Total/receitaTotal',
        type: 'POST',
        async: true,
        dataType: 'json',
        data:{'cidade': cidade},        
        success: function (result)
        {
            document.getElementById('loading2').style.display = 'none';                                    
            receitaChart.data.datasets.push({
                label: 'Total',
                fill: false,
                borderColor:'gold',
                backgroundColor: dynamicColors(),
                data: [ 
                    (result.receita_total[0][0].total), (result.receita_total[1][0].total), (result.receita_total[2][0].total), (result.receita_total[3][0].total), (result.receita_total[4][0].total), (result.receita_total[5][0].total), (result.receita_total[6][0].total), (result.receita_total[7][0].total), (result.receita_total[8][0].total), (result.receita_total[9][0].total), (result.receita_total[10][0].total), (result.receita_total[11][0].total), (result.receita_total[12][0].total), (result.receita_total[13][0].total), (result.receita_total[14][0].total), (result.receita_total[15][0].total), (result.receita_total[16][0].total), (result.receita_total[17][0].total), (result.receita_total[18][0].total), (result.receita_total[19][0].total), (result.receita_total[20][0].total), (result.receita_total[21][0].total), (result.receita_total[22][0].total), (result.receita_total[23][0].total), (result.receita_total[24][0].total), (result.receita_total[25][0].total), (result.receita_total[26][0].total), (result.receita_total[27][0].total), (result.receita_total[28][0].total), (result.receita_total[29][0].total), (result.receita_total[30][0].total)]
              });
            receitaChart.update();

        }
    })
}


function receitaPieTotal(cidade) {
    $.ajax ({
        url: '/index.php/Total/receitapietotal',
        type: 'POST',
        async: true,
        dataType: 'json',
        data:{'cidade': cidade},                
        success: function (result)
        {
            document.getElementById('loading3').style.display = 'none';                        
            porprodutoChart.data.datasets.push({
                label: 'Total',
                fill: false,
                borderColor:'white',
                backgroundColor: ["rgba(234, 28, 28, 0.82)", "rgba(51, 52, 185, 0.82)", "rgba(47, 234, 28, 0.76)", "rgba(232, 86, 171, 0.76)","rgba(44, 176, 154, 0.76)"],
                data: [ 
                    (result.captacao[0].bovespa), (result.captacao[0].futuros), (result.captacao[0].bancarios), (result.captacao[0].privados), (result.captacao[0].publicos)]
              });           
              
            porprodutoChart.update();
            
    
        }
    })
}



function captacaoLiquidaTotal(cidade) {
    $.ajax ({
        url: '/index.php/Total/captacaoLiquidaTotal',
        type: 'POST',
        async: true,
        dataType: 'json',
        data:{'cidade': cidade},                        
        success: function (result)
        {
            document.getElementById('loading4').style.display = 'none';  
            
            captLiquida.data.datasets.push({
                label: 'Total',
                fill: false,
                borderColor:'rgba(17, 131, 134, 0.83)',
                backgroundColor: ['rgba(17, 131, 134, 0.83)','rgba(234, 28, 28, 0.82)'],
                data: [ 
                    (result.captacao[0][0].total), (result.captacao[1][0].total), (result.captacao[2][0].total), (result.captacao[3][0].total), (result.captacao[4][0].total), (result.captacao[5][0].total), (result.captacao[6][0].total), (result.captacao[7][0].total), (result.captacao[8][0].total), (result.captacao[9][0].total), (result.captacao[10][0].total), (result.captacao[11][0].total), (result.captacao[12][0].total), (result.captacao[13][0].total), (result.captacao[14][0].total), (result.captacao[15][0].total), (result.captacao[16][0].total), (result.captacao[17][0].total), (result.captacao[18][0].total), (result.captacao[19][0].total), (result.captacao[20][0].total), (result.captacao[21][0].total), (result.captacao[22][0].total), (result.captacao[23][0].total), (result.captacao[24][0].total), (result.captacao[25][0].total), (result.captacao[26][0].total), (result.captacao[27][0].total), (result.captacao[28][0].total), (result.captacao[29][0].total), (result.captacao[30][0].total)]
              });           
              
              captLiquida.update();
            
        }
    })
}



function netbarTotal(cidade) {
    $.ajax ({
        url: '/index.php/Total/netTotal',
        type: 'POST',
        async: true,
        dataType: 'json',
        data:{'cidade': cidade},                                
        success: function (result)
        {
            document.getElementById('loading5').style.display = 'none';            
            net.data.datasets.push({
                label: 'Total',
                fill: false,
                borderColor:'white',
                backgroundColor: ["rgba(234, 28, 28, 0.82)", "rgba(51, 52, 185, 0.82)", "rgba(47, 234, 28, 0.76)", "rgba(232, 86, 171, 0.76)","rgba(44, 176, 154, 0.76)","rgba(255, 239, 95, 0.73)","rgba(64, 95, 88, 0.46)"],
                data: [ 
                    (result.net_produto[0].financeiro), (result.net_produto[0].imobiliarios), (result.net_produto[0].previdencia), (result.net_produto[0].rendafixa), (result.net_produto[0].rendavariavel), (result.net_produto[0].fundos), (result.net_produto[0].outros)]
              });           
              
              net.update();
        }
    })
}
var dynamicColors = function() {
    var r = Math.floor(Math.random() * 255);
    var g = Math.floor(Math.random() * 255);
    var b = Math.floor(Math.random() * 255);
    return "rgb(" + r + "," + g + "," + b + ")";
}



