function mudarsenha(senha) {
    $.ajax({
        url: '/index.php/Control/alterarSenha',
        type: 'POST',
        async: true,
        dataType: 'json',
        data: { 'senha': senha },
        success: function(result) {
            console.log(result);
        }
    })
}