function requisicao(id, data) {
    $.ajax({
        url: '/index.php/Comissao/requisicao',
        type: 'POST',
        async: true,
        dataType: 'json',
        data: { 'id': id, 'data': data },
        success: function(result) {
            div = document.getElementById('repasse');
            res = result.valor[0].repasse;
            r = document.getElementById('res');
            r.textContent = result.valor[0].repasse;
            p = document.createElement('p');
            p.textContent = "Repasse: " + res;
            div.appendChild(p);
            if (result.dados != '') {
                vetor = result.dados;
                localStorage.setItem('comissao', JSON.stringify(result.dados));
                matrizf = JSON.parse(localStorage.getItem("comissao"));
                $('#tbody').empty();
                var total = 0;
                tbody = document.querySelector('tbody');
                for (var i = 0; i <= matrizf.length; i++) {
                    var tr = document.createElement('tr');
                    var tdvalor = document.createElement('td');
                    var tdesc = document.createElement('td');
                    var tmais = document.createElement('td');
                    tr.id = i;
                    var tbutton = document.createElement('td');
                    var button = document.createElement('button');
                    tbutton.appendChild(button);
                    button.textContent = 'Deletar';
                    button.id = i;
                    button.setAttribute("class", "btn btn-danger");
                    button.setAttribute('onclick', 'excluir();');
                    tmais.textContent = matrizf[i].operacao;
                    tdvalor.textContent = matrizf[i].valor;
                    tdesc.textContent = matrizf[i].descricao;
                    tr.appendChild(tmais);
                    tr.appendChild(tdesc);
                    tr.appendChild(tdvalor);
                    tr.appendChild(button);
                    tbody.appendChild(tr);
                    valor = $("td:nth-child(3)");
                    operacao = $("td:nth-child(1)");
                    valores = 0;
                    for (var i = 0; i < valor.length; i++) {
                        if (operacao[i].textContent == '+') {
                            valores += parseFloat(valor[i].textContent);
                        } else {
                            valores -= parseFloat(valor[i].textContent);
                        }
                    }
                    total += parseFloat(document.getElementById('res').textContent) * 0.8491;
                    total += valores;


                }
                console.log("Valores:" + valores);
                console.log("Total:" + total);
                total = total.toFixed(2);
                document.getElementById('total').innerHTML = 'Total: R$' + total;

            }
        }
    })
}

function auxilio(auxilio, id_assessor, data) {
    $.ajax({
        url: '/index.php/Comissao/auxilio',
        type: 'POST',
        async: true,
        dataType: 'json',
        data: { 'auxilio': auxilio, 'id_assessor': id_assessor, 'data': data },
        success: function(result) {
            alert('Enviado com sucesso');
            window.location.reload();
        }
    })
}