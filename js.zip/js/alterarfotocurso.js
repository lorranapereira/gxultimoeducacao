
function alterarFoto(dataform) {
  	$.ajax ({
		url: '/index.php/Control/alterarFoto',
		type: 'POST',
		async: true,
		dataType: 'json',
		data: dataform,
		contentType: false,
		processData: false,
		success: function (result)
		{
			console.log(result.foto);
			var img = document.getElementById('img');
			$('#img').prop('src', "/perfil/"+result.foto); 
	  }
  })
}


